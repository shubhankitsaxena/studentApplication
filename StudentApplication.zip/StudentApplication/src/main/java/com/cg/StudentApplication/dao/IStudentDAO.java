package com.cg.StudentApplication.dao;

import java.util.List;

import com.cg.StudentApplication.model.Student;

public interface IStudentDAO {

	Student addStudent(Student student);

	List<Student> getAllStudents();

	Student updateStudent(String id, Student student);

	Student deleteStudent(String id);

	Student updateStudent1(String name, Student student);

	Student deleteStudent1(String name);

	Student getUserById(String id);

}

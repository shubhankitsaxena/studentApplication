package com.cg.StudentApplication.service;

import java.util.List;

import com.cg.StudentApplication.model.Student;

public interface IStudentService {

	Student addStudent(Student student);

	List<Student> getAllStudents();

	Student updateStudent(String id, Student student);

	Student deleteStudent(String id);

	Student updateStudent1(String name, Student student);

	Student deleteStudent1(String name);

	Student getUserById(String id);

}

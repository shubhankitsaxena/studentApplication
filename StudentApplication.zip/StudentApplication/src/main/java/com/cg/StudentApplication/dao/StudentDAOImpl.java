package com.cg.StudentApplication.dao;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.StudentApplication.model.Student;
@Repository
public class StudentDAOImpl implements IStudentDAO{
	@Autowired
private MongoTemplate mongoTemplate;
	@Override
	public Student addStudent(Student student) {
		mongoTemplate.save(student);
		return student;
	}
	@Override
	public List<Student> getAllStudents() {
		return mongoTemplate.findAll(Student.class);
	}
	@Override
	public Student updateStudent(String id, Student student) {
Query query = new Query();
query.addCriteria(Criteria.where("id").is(student.getId()));
mongoTemplate.findOne(query, Student.class);
 mongoTemplate.save(student);
return student;
	}
	@Override
public Student deleteStudent(String id) {
	Student student=getById(id);
		if(student!=null) {
 mongoTemplate.remove(student);			
		}
		return student;
	}
	private Student getById(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
	return	mongoTemplate.findOne(query, Student.class);
	}
	@Override
	public Student updateStudent1(String name, Student student) {
		Query query = new Query();
		query.addCriteria(Criteria.where("name").is(student.getName()));
		student.setName(name);
		mongoTemplate.findOne(query, Student.class);
		 mongoTemplate.save(student);
		return student;
	}
	@Override
	public Student deleteStudent1(String name) {
		Student student1=getByName(name);
		if(student1!=null) {
			mongoTemplate.remove(student1);
		}
		return student1;
	}
	private Student getByName(String name) {
		Query query = new Query();
		query.addCriteria(Criteria.where("name").is(name));
	return	mongoTemplate.findOne(query, Student.class);		
	}
	@Override
	public Student getUserById(String id) {

		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		return mongoTemplate.findOne(query, Student.class);
	}
		
	}



package com.cg.StudentApplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.StudentApplication.dao.IStudentDAO;
import com.cg.StudentApplication.model.Student;

@Service
public class StudentServiceIMPL implements IStudentService {
	@Autowired
private IStudentDAO studentDao;
	@Override
	public Student addStudent(Student student) {
		return studentDao.addStudent(student);
	}
	@Override
	public List<Student> getAllStudents() {
		return studentDao.getAllStudents();
	}
	@Override
	public Student updateStudent(String id, Student student) {
		student.setId(id);
		return studentDao.updateStudent(id,student);
	}
	@Override
	public Student deleteStudent(String id) {
		return studentDao.deleteStudent(id);
	}
	@Override
	public Student updateStudent1(String name, Student student) {
	
		return studentDao.updateStudent1(name,student);
	}
	@Override
	public Student deleteStudent1(String name) {
		return studentDao.deleteStudent1(name);
	}
	@Override
	public Student getUserById(String id) {
	return studentDao.getUserById(id);
	}


}

package com.cg.StudentApplication.model;

import java.util.Date;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class Student {
	
	@Id
	private String id;
	@NotNull
	@Size(min=2,message="name should be valid")
	String name;
	private int age;
	private Date dob =new Date();
	private Map<String,String> marks=new HashMap<>();
	public Student() {
		super();
	}
	public Student(String id, String name, int age, Date dob, Map<String, String> marks) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.dob = dob;
		this.marks = marks;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Map<String, String> getMarks() {
		return marks;
	}
	public void setMarks(Map<String, String> marks) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", dob=" + dob + ", marks=" + marks + "]";
	}
}

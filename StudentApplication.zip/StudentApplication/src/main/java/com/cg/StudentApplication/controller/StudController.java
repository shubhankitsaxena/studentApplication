package com.cg.StudentApplication.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.StudentApplication.exceptions.UserNotFoundException;
import com.cg.StudentApplication.model.Student;
import com.cg.StudentApplication.service.IStudentService;

@RestController
@RequestMapping("/Student")
public class StudController {
	@Autowired
private IStudentService service;
@RequestMapping(value="/create", method=RequestMethod.POST)
public Student addStudent(@Valid @RequestBody Student student) {
	return service.addStudent(student);
	
}
@RequestMapping(value="/read" , method=RequestMethod.GET)
public List<Student> getAllStudents(){
	return service.getAllStudents();
	
}
@RequestMapping(value="/update/{id}" , method= RequestMethod.PUT)
public Student updateStudent(@PathVariable String id , @RequestBody Student student) {
	return service.updateStudent(id,student);
	
}@RequestMapping(value="/updateData/{name}" , method= RequestMethod.PUT)
public Student updateStudent1(@PathVariable String name , @RequestBody Student student) {
	return service.updateStudent1(name,student);
}
@RequestMapping(value="/delete/{id}" , method =RequestMethod.DELETE)
public Student deleteStudent(@PathVariable String id) {
	return service.deleteStudent(id);
}
@RequestMapping(value="/delete1/{name}" , method =RequestMethod.DELETE)
public Student deleteStudent1(@PathVariable String name) {
	return service.deleteStudent1(name);
}
@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Student getUser(@PathVariable String id) {
    Student  student = service.getUserById(id);
    if( student == null)
    {
    	throw new UserNotFoundException(" User Not Found ");
    }
    
    return student;
}
}
